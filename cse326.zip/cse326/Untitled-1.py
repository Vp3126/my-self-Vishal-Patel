

class Mahindra:
  ename="mHawk"
  ecc=2200
class Thar(Mahindra):
  def details(self, power, torque):
    self.p=power
    self.t=torque
    print("Thar")
    print("Power is",self.p)
    print("torque is",self.t)
class Scorpio(Mahindra):
  def details(self, power, torque):
    self.p=power
    self.t=torque
    print("Scorpio")
    print("Power is",self.p)
    print("torque is",self.t)
t1=Thar()
s1=Scorpio()
t1.details(182,465)
s1.details(686,586)
