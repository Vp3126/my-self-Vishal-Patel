fr=open("example.txt","w")
fr.write("hello python-\nINT-108")
fr.close()
f=open("example.txt","r")
print(f.readline(4))
#readline read only first line 
#read tag read entire page 
# write in file : 


#append: syntax is same we write a insteed of w
fr=open("example.txt","a")
fr.write("see uhh soon")
fr.close()
#open and read the file after the appending:
f=open("example.txt","r")
print(f.read())

# copy of the file:
f1=open("example.txt","w")
f1.write("something")
# f1.write("to eat")
f1=open("example.txt","r")
f2=open("xyz.txt","w")
for i in f1:
    f2.write(i)
f2.close()
f2=open("xyz.txt","r")
print(f2.read())

f1=open("example.txt","w")
f1.write("hello python-\nINT-108")
f1.close()
f2=open("example.txt","r")
print(f2.read())
print(f2.seek(9))
print(f2.read(1))
print(f2.tell())